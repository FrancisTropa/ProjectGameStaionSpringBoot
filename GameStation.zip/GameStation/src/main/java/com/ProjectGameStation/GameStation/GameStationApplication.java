package com.ProjectGameStation.GameStation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameStationApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameStationApplication.class, args);
	}

}
